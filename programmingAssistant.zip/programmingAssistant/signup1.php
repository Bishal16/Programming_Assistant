
<?php

$nextstage=1;
$server      = "localhost";
$password    = "";
$user        = "root";
$database    = "programming_assistant";
$connection = mysqli_connect($server, $user, $password, $database);

if($_SERVER["REQUEST_METHOD"]=="POST"){
    
    $userName=$_POST["userName"];
  
    $pass=$_POST["password"];
    $cpass=$_POST["cpassword"];
    $email=$_POST["email"];
    
    
    
    
    if($pass != $cpass){
        echo "*Password did not match"."<br>";
        $nextstage = 0;
    }
    if(!$pass){
        echo "*password required".'<br>';
        $nextstage = 0;
    }
    if(!$userName){
        echo '*first name required'.'<br>';
        $nextstage = 0;
    }

    
    if(!$email){
        echo '*email required'.'<br>';
        $nextstage = 0;
    }

    if($nextstage==1){
        
        $sql= "Insert into userinfo (userName,password,email) values('$userName','$pass','$email')";
        $iquery = mysqli_query($connection,$sql);
        
        if($iquery)
        {
            echo 'successful'.'<br>';
            header("Location: index.php");
        }
        else
        {
            echo 'failed to insert data'.'<br>';
        }
        
        
    }
}

mysqli_close($connection);

?>